import { Component } from '@angular/core';

@Component({
    selector: 'home-app',
    templateUrl: 'app/templates/home.html'
})

export class HomeComponent {
    title = 'Home Page';
}
