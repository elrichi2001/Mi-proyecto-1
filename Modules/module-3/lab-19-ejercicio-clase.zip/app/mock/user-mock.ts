import {User} from "../model/user";

export const USERS: User[] = [
    {
        id: 1,
        name: "Alejandro Romero"
    },
    {
        id: 2,
        name: "Pedro Chin"
    },
    {
        id: 3,
        name: "Jaime Meluq"
    }
];