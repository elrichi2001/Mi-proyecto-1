import {Product} from "../model/product";

export const PRODUCTS: Product[] = [
    {
        id: 1,
        name: "Samsung galaxy 8"
    },
    {
        id: 2,
        name: "Samsung galaxy 10"
    },
    {
        id: 3,
        name: "Samsung galaxy 20"
    }
];
