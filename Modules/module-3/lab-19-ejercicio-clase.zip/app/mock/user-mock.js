"use strict";
exports.USERS = [
    {
        id: 1,
        name: "Alejandro Romero"
    },
    {
        id: 2,
        name: "Pedro Chin"
    },
    {
        id: 3,
        name: "Jaime Meluq"
    }
];
//# sourceMappingURL=user-mock.js.map